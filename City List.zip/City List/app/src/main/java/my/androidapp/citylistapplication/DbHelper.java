package my.androidapp.citylistapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbHelper extends SQLiteOpenHelper {
    private static final String dbName = "citystore.db";
    private static final int SCHEMA = 1;
    static final String TABLE = "cities";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "name";


    public DbHelper(Context context) {
        super(context, dbName, null, SCHEMA);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE cities (" + COLUMN_ID
                + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_NAME
                + " TEXT);");

        db.execSQL("INSERT INTO "+ TABLE +" (" + COLUMN_NAME
                + " ) VALUES ('Hollywood'), ('Room 209'), ('Estadio do Dragao')," +
                "   ('Big Apple'),('Mars'),('Room 101'),('The Caf'),('Hinds County')," +
                "('Inferno'),('Canada');");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,  int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE);
        onCreate(db);
    }
}
