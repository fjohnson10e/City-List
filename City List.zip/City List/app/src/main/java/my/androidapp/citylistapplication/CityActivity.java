package my.androidapp.citylistapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CityActivity extends AppCompatActivity {

    /***
     * Declare visual elements,
     * as well as objects for working with a data base
     */
    EditText editNameCity;
    Button deleteButton;
    Button saveButton;

    DbHelper dbHelper;
    SQLiteDatabase db;
    Cursor cityCursor;
    long cityId =0;

    /**
     *In this case, when creating an activity, we expect from the
     * main activity to receive data - the id of the element,
     * if it is not there - there is nothing to
     * edit and we create an object, if there
     * is, we edit it and save it in the database
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city);
        editNameCity = (EditText) findViewById(R.id.name);
        deleteButton = (Button) findViewById(R.id.deleteButton);
        saveButton = (Button) findViewById(R.id.saveButton);
        dbHelper = new DbHelper(this);
        db = dbHelper.getWritableDatabase();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            cityId = extras.getLong("id");
        }
        // If the database has no Id, then add the elements
        if (cityId > 0) {
            // get an element by id from the database
            cityCursor = db.rawQuery("select * from " + DbHelper.TABLE + " where " +
                    DbHelper.COLUMN_ID + "=?", new String[]{String.valueOf(cityId)});
            cityCursor.moveToFirst();
            editNameCity.setText(cityCursor.getString(1));
            cityCursor.close();
        } else {
            // hide delete button
            deleteButton.setVisibility(View.GONE);
        }
    }
     //when we click on the save button, we get
     // the object from the database and save what is in the text field
    public void save(View view){
        ContentValues cv = new ContentValues();
        if(!editNameCity.getText().toString().trim().isEmpty()){
            cv.put(DbHelper.COLUMN_NAME, editNameCity.getText().toString());

            if (cityId > 0) {
                db.update(DbHelper.TABLE, cv, DbHelper.COLUMN_ID + "=" + String.valueOf(cityId), null);
            } else {
                db.insert(DbHelper.TABLE, null, cv);
            }
            goHome();
        }else {
            Toast toast = Toast.makeText(this, "The field must not be empty",Toast.LENGTH_LONG);
            toast.show();
        }

    }
    public void delete(View view){
        db.delete(DbHelper.TABLE, "_id = ?", new String[]{String.valueOf(cityId)});
        goHome();
    }
    private void goHome(){
        // close connection
        db.close();
        // go to main activity
        Intent intent = new Intent(this, MainActivity.class);
        //clear the list of activities and display the main activity again.
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }
}