package my.androidapp.citylistapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

public class MainActivity extends AppCompatActivity {

    /***
     * Declare visual elements,
     * as well as objects for working with a data base
     */
    ListView cityList;
    DbHelper dbHelper;
    SQLiteDatabase db;
    Cursor cityCursor;
    SimpleCursorAdapter cityAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //As soon as the main activity is created,
        // we define the accessibility to the visual elements.
        cityList = findViewById(R.id.list);
        //When we click on an element,
        // we will go to another activity for editing.
        cityList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), CityActivity.class);
                intent.putExtra("id", id);
                startActivity(intent);
            }
        });
        //Objects for working with the database are also defined.
        dbHelper = new DbHelper(getApplicationContext());
    }

    @Override
    public void onResume() {
        super.onResume();
        // open connection
        db = dbHelper.getReadableDatabase();
        //get data from database with cursor
        cityCursor = db.rawQuery("select * from " + DbHelper.TABLE, null);
        // we determine which columns from the course will be displayed in the ListView
        String[] headers = new String[]{DbHelper.COLUMN_NAME};
        // create an adapter, pass the course to itр
        cityAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_dropdown_item_1line,
                cityCursor, headers, new int[]{android.R.id.text1}, 0);
        cityList.setAdapter(cityAdapter);
    }

    // by clicking on the button, launch CityActivity to add data
    public void add(View view) {
        Intent intent = new Intent(this, CityActivity.class);
        startActivity(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Closing the connection and cursor
        db.close();
        cityCursor.close();
    }
}